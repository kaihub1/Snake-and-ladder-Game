﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using static Packet.Class1;


namespace Server
{
    public partial class Form1 : Form
    {
        private delegate void srvDelegate(object temp, int loc);

        private TcpListener listener;
        private Socket connection;
        NetworkStream connectionStream = null;

        //Wait For Connection thread
        //Manages incoming connections
        private Thread WFCThread = null;
        private static BinaryFormatter formatter = new BinaryFormatter();
        Thread[] AllThreads;
        CData[] AllSockets;
        int NextLocation = 0;

        public Form1()
        {
            InitializeComponent();
            AllThreads = new Thread[5]; //creates array
            AllSockets = new CData[5]; //creates array
        }

        private void btnStartServer_Click(object sender, EventArgs e)
        {
            //WFCThread == null
            //If the thread has never been created
            //OR
            //If the thread is dead
            //IsAlive is a proprty that tells us if
            if (WFCThread == null || !WFCThread.IsAlive)
            {
                //Is this a parameterized thread? No
                WFCThread = new Thread(new ThreadStart(WFCProcedure));
                WFCThread.Start();
            }
        }

        private void btnStopServer_Click(object sender, EventArgs e)
        {
            if (WFCThread != null && WFCThread.IsAlive)
            {
                listener.Stop(); //stops the blocking call listener.AcceptSocket()
                NextLocation = 0;
            }

            for (int x = 0; x < 5; x++)
            {
                if (AllSockets[x] != null && AllThreads[x] != null && AllThreads[x].IsAlive)
                {
                    AllSockets[x].TheSocket.Close();
                    AllThreads[x].Join();
                    AllThreads[x] = null;
                    AllSockets[x] = null;
                }
            }
        }

        private void WFCProcedure()
        {
            int port = 3005;
            IPAddress localAddr = IPAddress.Parse("127.0.0.1");

            listener = new TcpListener(localAddr, port);
            listener.Start();

            try
            {
                while (NextLocation < 5)
                {
                    connection = listener.AcceptSocket(); //blocking call
                    MessageBox.Show("Connection Made");

                    AllSockets[NextLocation] = new CData();

                    //If we want to shut this down, we need the socket
                    AllSockets[NextLocation].TheSocket = connection;

                    //This is the stream (Think of it like a pointer to the client)
                    AllSockets[NextLocation].ConnStream = new NetworkStream(connection);
                    AllSockets[NextLocation].Connected = true;

                    //Can be used to track which client connection this is. 
                    //Might not need this, but we have it for debugging
                    AllSockets[NextLocation].which = NextLocation;

                    AllThreads[NextLocation] = new Thread(new ParameterizedThreadStart(AreYouTalkingToME));
                    AllThreads[NextLocation].Start(AllSockets[NextLocation]);
                    NextLocation++;
                }
            }
            catch (SocketException)
            {
                MessageBox.Show("Server Shutting down!");
            }
        }

        private void AreYouTalkingToME(object obj) //obj is really a.. CData object
        {
            CData who = null;
            object temp;
            if (obj is CData)
            {
                who = (CData)obj;
            }

            try
            {
                while (true)
                {
                    if (who != null)
                    {
                        temp = formatter.Deserialize(who.ConnStream);  //Blocking Call

                        if (temp is PlayerName)
                        {
                            PlayerName pname = (PlayerName)temp;
                            AllSockets[who.which].PlayerName = pname.name;
                        }
                        else if (temp is Packet.Class1.Message)
                        {
                            //Put messages in the listbox
                            if (listBox1.InvokeRequired)
                            {
                                BeginInvoke(new srvDelegate(SendToListbox), temp, who.which);
                            }
                            IDMessage idm = new IDMessage();

                            string PlayerId = "";

                            if (AllSockets[who.which].PlayerName != "")
                            {
                                PlayerId = AllSockets[who.which].PlayerName;

                            }
                            else
                            {
                                PlayerId = "Player " + who.which.ToString();
                            }
                            idm.name = PlayerId;
                            idm.message = ((Packet.Class1.Message)temp).message;

                            for (int x = 0; x < 5; x++)
                            {
                                if (AllSockets[x] != null)
                                {
                                    if (AllSockets[x].which != who.which)
                                        formatter.Serialize(AllSockets[x].ConnStream, idm); //send new message to clients
                                }
                            }
                        }
                        else
                        {
                            //Put whatever in the listbox and send it to all other clients
                            if (listBox1.InvokeRequired)
                            {
                                BeginInvoke(new srvDelegate(SendToListbox), temp, who.which);
                            }
                            for (int x = 0; x < 5; x++)
                            {
                                if (AllSockets[x] != null)
                                {
                                    if (AllSockets[x].which != who.which)
                                        formatter.Serialize(AllSockets[x].ConnStream, temp); //send new message to clients
                                }
                            }
                        }

                    }
                }
            }
            catch (System.IO.IOException)
            {
                MessageBox.Show("Client Died!");
            }
        }
        private void SendToListbox(object obj, int location)// temp and who.which passed in
        {

            string PlayerId = "";

            if (AllSockets[location].PlayerName != "")
            {
                PlayerId = AllSockets[location].PlayerName;

            }
            else
            {
                PlayerId = "Player " + location.ToString();
            }

            if (obj is Packet.Class1.Message)
            {
                Packet.Class1.Message m = (Packet.Class1.Message)obj;
                AddTime(PlayerId + " " + m.message);
                listBox1.Items.Add(PlayerId + " " + m.message);
            }
            else if (obj is Question)
            {
                Question q = (Question)obj;
                AddTime(PlayerId + " " + q.Operand1.ToString() + q.Operator + q.Operand2.ToString());
                listBox1.Items.Add(PlayerId + " " + q.Operand1.ToString() + q.Operator + q.Operand2.ToString());
            }
            else if (obj is string)
            {
                AddTime(PlayerId + " " + (string)obj);
                listBox1.Items.Add(PlayerId + " " + (string)obj);
            }
        }

        private void AddTime(string s = " ")
        {
            DateTime dateTime = DateTime.Now;
            listBox1.Items.Add(dateTime.ToString() + " ");

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
