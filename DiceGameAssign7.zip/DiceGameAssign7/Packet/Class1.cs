﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Packet
{
    public class Class1
    {

        [Serializable]
        public class Packet
        {
        }

        [Serializable]
        public class Message : Packet
        {
            public string message;
        }

        [Serializable]
        public class IDMessage : Packet
        {
            public string name;
            public string message;
        }

        [Serializable]
        public class Question : Packet
        {
            public string Operator;
            public int Operand1;
            public int Operand2;
        }

        [Serializable]
        public class PlayerName : Packet
        {
            public string name;
        }

        [Serializable]

        public class Dice : Packet
        {
            
        }

        [Serializable]

        public class x : Packet
        {

        }

        [Serializable]

        public class y : Packet
        {

        }

        [Serializable]

        public class token : Packet
        {

        }

        [Serializable]

        public class Snakes : Packet
        {

        }

        [Serializable]

        public class Ladder : Packet
        {

        }

        [Serializable]

        public class CreateGame : Packet
        {
            public string cg;
            public int amount_game;

            public override string ToString()
            {
                return cg;
            }
        }

    }
}
