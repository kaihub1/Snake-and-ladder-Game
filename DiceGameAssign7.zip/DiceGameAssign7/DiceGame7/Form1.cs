﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using static Packet.Class1;


namespace DiceGame7
{
    public partial class Form1 : Form
    {
        private delegate void clDelegate(object temp);
        private Thread TalkThread = null;
        NetworkStream clientStream = null;
        private static BinaryFormatter formatter = new BinaryFormatter();

        ClientText fclient = new ClientText();

        Random rand_dice = new Random();
        
        int x = 20;
        int y = 371;
        int dicenum;
        bool blue = false;
        bool green = false;
        int dice1;
        //int[] loc = new int[100];
        int tokenLoc = 0;
        int x1 = 21;
        int y1 = 370;
        int tokenLoc1 = 0;
        int xwin = 412;
        int ywin = 28;

        public Form1()
        {
            InitializeComponent();
            
        }


        private void Win()
        {

            //if(dice1 + tokenLoc == xwin)

            if (dice1 + tokenLoc > 100)
            {
                MessageBox.Show("Can't Move ahead! Roll Dice Again");


            }
            if (tokenLoc == 100)
            {
                MessageBox.Show("YOU WIN!!");
                button1.Enabled = false;


            }
        }

        private void Win1()
        {
            if (dice1 + tokenLoc1 > 100)
            {
                MessageBox.Show("Can't Move ahead! Roll Dice Again");


            }
            if (tokenLoc1 == 100)
            {
                MessageBox.Show("YOU WIN!!");
                button2.Enabled = false;


            }
        }

        private  void GoAhead()
        {

           


            for (int i = 0; i < dice1; i++)
            {
                if (tokenLoc == 10)
                {
                    x = 20;
                    y = 333;


                }
                else if (tokenLoc == 20)
                {
                    x = 20;
                    y = 295;

                }
                else if (tokenLoc == 30)
                {
                    x = 20;
                    y = 258;

                }
                else if (tokenLoc == 40)
                {
                    x = 20;
                    y = 220;

                }
                else if (tokenLoc == 50)
                {
                    x = 20;
                    y = 180;

                }
                else if (tokenLoc == 60)
                {
                    x = 20;
                    y = 140;

                }
                else if (tokenLoc == 70)
                {
                    x = 20;
                    y = 108;

                }
                else if (tokenLoc == 80)
                {
                    x = 20;
                    y = 67;

                }
                else if (tokenLoc == 90)
                {
                    x = 20;
                    y = 31;

                }
                else
                {
                    x += 43;
                }


                pictureBox2.Location = new Point(x, y);
                label3.Text = x.ToString();
                label6.Text = y.ToString();
                tokenLoc++;
                


               


               
            }



            if (tokenLoc == 5)
            {
                x = 69;
                y = 260;
                tokenLoc = 32;
            }
            else if (tokenLoc == 59)
            {
                x = 354;
                y = 33;
                tokenLoc = 99;

            }
            else if (tokenLoc == 75)
            {
                x = 273;
                y = 32;
                tokenLoc = 97;
            }


            if (tokenLoc == 36)
            {
                x = 200;
                y = 297;
                tokenLoc = 25;
            }
            else if (tokenLoc == 40)
            {
                x = 354;
                y = 334;
                tokenLoc = 19;
            }
            else if (tokenLoc == 78)
            {
                x = 193;
                y = 184;
                tokenLoc = 55;
            }
            else if (tokenLoc == 91)
            {
                x = 151;
                y = 181;
                tokenLoc = 54;
            }
            pictureBox2.Location = new Point(x, y);
            
            label3.Text = x.ToString();
            label6.Text = y.ToString();

            


        }

        private void GoAhead1()
        {




            for (int i = 0; i < dice1; i++)
            {
                if (tokenLoc1 == 10)
                {
                    x1 = 20;
                    y1 = 333;


                }
                else if (tokenLoc1 == 20)
                {
                    x1 = 20;
                    y1 = 295;

                }
                else if (tokenLoc1 == 30)
                {
                    x1 = 20;
                    y1 = 258;

                }
                else if (tokenLoc1 == 40)
                {
                    x1 = 20;
                    y1 = 220;

                }
                else if (tokenLoc1 == 50)
                {
                    x1 = 20;
                    y1 = 180;

                }
                else if (tokenLoc1 == 60)
                {
                    x1 = 20;
                    y1 = 140;

                }
                else if (tokenLoc1 == 70)
                {
                    x1 = 20;
                    y1 = 108;

                }
                else if (tokenLoc1 == 80)
                {
                    x1 = 20;
                    y1 = 67;

                }
                else if (tokenLoc1 == 90)
                {
                    x1 = 20;
                    y1 = 31;

                }
                else
                {
                    x1 += 43;
                }


                pictureBox3.Location = new Point(x1, y1);
                label9.Text = x1.ToString();
                label10.Text = y1.ToString();
                tokenLoc1++;







            }



            if (tokenLoc1 == 5)
            {
                x1 = 69;
                y1 = 260;
                tokenLoc1 = 32;
            }
            else if (tokenLoc1 == 59)
            {
                x1 = 354;
                y1 = 33;
                tokenLoc1 = 99;

            }
            else if (tokenLoc1 == 75)
            {
                x1 = 273;
                y1 = 32;
                tokenLoc1 = 97;
            }


            if (tokenLoc1 == 36)
            {
                x1 = 200;
                y1 = 297;
                tokenLoc1 = 25;
            }
            else if (tokenLoc1 == 40)
            {
                x1 = 354;
                y1 = 334;
                tokenLoc1 = 19;
            }
            else if (tokenLoc1 == 78)
            {
                x1 = 193;
                y1 = 184;
                tokenLoc1 = 55;
            }
            else if (tokenLoc1 == 91)
            {
                x1 = 151;
                y1 = 181;
                tokenLoc1 = 54;
            }
            pictureBox3.Location = new Point(x1, y1);

            label9.Text = x1.ToString();
            label10.Text = y1.ToString();




        }





        private void button1_Click(object sender, EventArgs e) // roll dice
        {
           // SnakesLoc();
           // LadderLoc();
           // pictureBox2.Visible = false;
            dice1 = rand_dice.Next(1, 7);
           
            
            //dicenum = dice1;
            pictureBox1.Image = Image.FromFile(@"..\..\..\Dice pics\" + dice1 + @".png");
            label1.Text = dice1.ToString();
            

            if (blue == true && dice1 + tokenLoc <= 100)
            {

                GoAhead();
                
                label3.Text = x.ToString();
                label6.Text = y.ToString();

            }
            
            if (label1.Text == "1" && blue == false)
            {

                pictureBox2.Visible = true;
                pictureBox5.Visible = false;
                blue = true;
                pictureBox2.Location = new Point(x, y);
                label3.Text = x.ToString();
                label6.Text = y.ToString();
                tokenLoc++;
                
            }
            Win();

        }

        
              

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)  // menu
        {

        }

        
        public void TalkProcedure()
        {
            object temp;
            try
            {
                while (true)
                {
                    MessageBox.Show("Waiting");
                    temp = formatter.Deserialize(clientStream); //blocking call

                    //if (listBox1.InvokeRequired)
                    //{
                    //    BeginInvoke(new clDelegate(SendToListbox), temp);
                    //}
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Lost Connection");
            }
        }


        private void toolStripMenuItem2_Click(object sender, EventArgs e)  // connect
        {

            fclient.mainForm = this;
            fclient.ShowDialog();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            dice1 = rand_dice.Next(1, 7);

            pictureBox1.Image = Image.FromFile(@"..\..\..\Dice pics\" + dice1 + @".png");
            label12.Text = dice1.ToString();


            if (green == true && dice1 + tokenLoc1 <= 100)
            {

                GoAhead1();

                label9.Text = x1.ToString();
                label10.Text = y1.ToString();

            }
            
            if (label12.Text == "1" && green == false)
            {

                pictureBox3.Visible = true;
                pictureBox4.Visible = false;
                green = true;
                pictureBox3.Location = new Point(x1, y1);
                label9.Text = x1.ToString();
                label10.Text = y1.ToString();
                tokenLoc1++;

            }
            Win1();






        }

        private void quitGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            

        }
    }
}
