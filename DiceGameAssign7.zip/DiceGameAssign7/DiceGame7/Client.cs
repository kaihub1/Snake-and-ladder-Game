﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using static Packet.Class1;

namespace DiceGame7
{
    public partial class ClientText : Form
    {
        private delegate void clDelegate(object temp);
        private delegate void glDelegate(List<string> GameList);
        private Thread TalkThread = null;
        public NetworkStream clientStream = null;
        private static BinaryFormatter formatter = new BinaryFormatter();
        public Form1 mainForm = null;
        public ClientText()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (TalkThread == null || !TalkThread.IsAlive)
            {
                TcpClient client = new TcpClient();
                try
                {
                    client.Connect(textBox1.Text, 3005);
                    clientStream = client.GetStream();

                    TalkThread = new Thread(new ThreadStart(mainForm.TalkProcedure));
                    TalkThread.Start();
                }
                catch (SocketException)
                {
                    MessageBox.Show("Cannot connect to server");
                }

            }
        }

        public void UpdateGameList(List<string> GameList)
        {
            if (InvokeRequired) //Are you the second thread?
            {
                BeginInvoke(new glDelegate(UpdateGameList), GameList); //Yes! Ask the first thread to run this code

            }
            else
            {
                listBox2.Items.Clear();
                for (int i = 0; i < GameList.Count; i++)
                {
                    listBox2.Items.Add(GameList[i]);
                }
            }
        }

        //public void TalkProcedure()
        //{
        //    object temp;
        //    try
        //    {
        //        while (true)
        //        {
        //            MessageBox.Show("Waiting");
        //            temp = formatter.Deserialize(clientStream); //blocking call

        //            //if (listBox1.InvokeRequired)
        //            //{
        //            //    BeginInvoke(new clDelegate(SendToListbox), temp);
        //            //}
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        MessageBox.Show("Lost Connection");
        //    }
        //}

        private void SendToListbox(object obj)
        {
            if (obj is Packet.Class1.Message)
            {
                Packet.Class1.Message m = (Packet.Class1.Message)obj;
                listBox1.Items.Add(m.message);
            }
            else if (obj is Question)
            {
                Question q = (Question)obj;
                listBox1.Items.Add(q.Operand1.ToString() + q.Operator + q.Operand2.ToString());
            }
            else if (obj is IDMessage)
            {
                IDMessage idm = (IDMessage)obj;
                listBox1.Items.Add(idm.name + " " + idm.message);
            }
            else if (obj is string)
            {
                listBox1.Items.Add((string)obj);
            }
        }

        private void btnSendMessage_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientStream != null && clientStream.CanWrite)
                {
                    Packet.Class1.Message m = new Packet.Class1.Message();
                    m.message = textBox2.Text;
                    formatter.Serialize(clientStream, m); //send data
                }
            }
            catch (System.IO.IOException)
            {

            }
        }

        private void btnSendQuestion_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientStream != null && clientStream.CanWrite)
                {
                    Question q = new Question();
                    q.Operator = "+";
                    q.Operand1 = 12;
                    q.Operand2 = 21;

                    formatter.Serialize(clientStream, q); //send data
                }
            }
            catch (System.IO.IOException)
            {

            }
        }

        private void btnUser_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientStream != null && clientStream.CanWrite)
                {
                    PlayerName m = new PlayerName();
                    m.name = textBox3.Text;
                    formatter.Serialize(clientStream, m); //send data
                }
            }
            catch (System.IO.IOException)
            {

            }
        }

      

        private void button7_Click(object sender, EventArgs e)   // start button
        {


            


        }

        private void button6_Click(object sender, EventArgs e)    // create game
        {


            try
            {
                if (clientStream != null && clientStream.CanWrite)
                {
                    Packet.Class1.CreateGame g = new Packet.Class1.CreateGame();
                    g.cg = textBox4.Text;
                    formatter.Serialize(clientStream, g); 
                }
            }
            catch (System.IO.IOException)
            {

            }



        }

        
    }


}
    

